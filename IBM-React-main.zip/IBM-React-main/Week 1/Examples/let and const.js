{
  let a = 10;
  console.log(a);
  a = 15;
  console.log(a);
}
console.log(a);
const num = 5;
console.log(num);
num = 8;
console.log(num);
