import React from 'react';
import {Text} from 'react-native’;
const Helloworld= ()=>
{
    return
    (Hello, World!);
}
export default Helloworld;