import React from "react";
function App() {
  return (
    <div>
      <p>This is the sample JSX</p>
      <ul>
        <li>List No. 1</li>
        <li>List No. 2</li>
      </ul>
    </div>
  );
}
