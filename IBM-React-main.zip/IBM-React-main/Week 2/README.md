### `Hands-on Lab - React Todo_List Application
Estimated Time Needed: 1 hour 30 mins
In this lab, you will be building a TODO list application using React components.You will discover how to create, view, delete, complete, modify and save to-do lists.

Objective:

After completing this lab, you will be able to:

Use event handler for creating add todo task.

Delete the completed task from todo list using filter method.

Add the Toggle function and checkbox to check completed or not completed task.

Edit a added Todo task and submit it using map function.

Use the UseEffect hook to save new todos into localstorage.

Next